// Native Audio
// Copyright (c) 2018, Sirawat Pitaksarit, Exceed7 Experiments <5argon@exceed7.com>
// Problems/suggestions : 5argon@exceed7.com

#include <stdlib.h>
#include <assert.h>
#include <jni.h>
#include <string.h>
#include <pthread.h>
#include <math.h>

// For logging
#include <android/log.h>

// for native audio
#include <SLES/OpenSLES.h>
#include <SLES/OpenSLES_Android.h>

//For resampling to native rate. I have included the lib inside this project.
//Do not forget to comply to BSD license by putting an appropriate attribution.
//See LICENSE file included with NativeAudio.
#include "libsamplerate-0.1.9/src/samplerate.h"
#include "stb_vorbis.h"

typedef struct CallbackCntxt_ {
    int sourceIndex;
    int playerIndex; //This is the "specified" player index. -1 if from round-robin. (usually it is that)
    int timesPlayed;
    //For track pausing
    int savedTimesPlayed;
    int totalTimesRequired;
    //To implement pause/resume we need to be able to start from any point.
    //By any point it is impossible to still line up the audio with native buffer size.
    //This offset will help us pinpoint the exact time, then resume playing in a lined up way.
    int offsetByte;
    char playingSilence;
    //An anchor so we can get the current playback time.
    float startPlaybackTimeAbsolute;
    float savedPlaybackTimeAbsolute;
    jboolean savedTrackLoopStatus;

    jboolean trackLoop;
} CallbackState;

typedef struct
{
    int audioPlayerIndex;
    float volume;
    float pan;
    float offsetSeconds;
    jboolean trackLoop;
} PlayOptions;

typedef struct
{
    SLuint32 byteLength;
    SLuint32 unpaddedByteLength;
    float lengthSeconds;
    char channels;
    char bitDepth;
} AudioSpecs ;

// engine interfaces
static SLObjectItf engineObject = NULL;
static SLEngineItf engineEngine;

// output mix interfaces
static SLObjectItf outputMixObject = NULL;
static SLEnvironmentalReverbItf outputMixEnvironmentalReverb = NULL;

//We will have "audioPlayerCount" amount of each of these!
static SLObjectItf *bqPlayerObjects;
static SLPlayItf *bqPlayerPlays;
static SLAndroidSimpleBufferQueueItf *bqPlayerBufferQueues;
static SLVolumeItf *bqPlayerVolumes;
static CallbackState *bqCallbackStates;

static SLmilliHertz nativeSamplingRate = 0;
static size_t nativeBufferSize = 0;

//#define ENABLE_LOGGING

#if defined(ENABLE_LOGGING)
#define Log(...) __android_log_print(ANDROID_LOG_INFO, "Native Audio - OpenSL ES", __VA_ARGS__)
#else
#define Log(...)
#endif

//Your phone has a maximum of 32 audio track with 7 max fast track.
static int audioPlayerCount = 0;

//Everything we have loaded in here! (resampled if necessary)
static short **loadedAudioCollection;

//Need to feed silence to keep the track active, prevents AudioPolicyManager from activating.
static char *silence;

//Storing the byte length so the buffer queue can just take it and play to the correct length.
static AudioSpecs *loadedAudioSpecs;

//Always increasing, unloading will not decrease this running number.
static int amountOfLoadedAudio = 0;

void disposeIfAllocated()
{
    // Stop all the running callbacks

    // destroy buffer queue audio player object, and invalidate all associated interfaces
    // audioPlayerCount would only be non zero according to created sources..
    for (int i = 0; i < audioPlayerCount; ++i) {

        if (bqPlayerObjects[i] != NULL) {
            (*bqPlayerObjects[i])->Destroy(bqPlayerObjects[i]);
            bqPlayerObjects[i] = NULL;
            bqPlayerPlays[i] = NULL;
            bqPlayerBufferQueues[i] = NULL;
            bqPlayerVolumes[i] = NULL;
        }
    }

    // destroy output mix object, and invalidate all associated interfaces
    if (outputMixObject != NULL) {
        (*outputMixObject)->Destroy(outputMixObject);
        outputMixObject = NULL;
        outputMixEnvironmentalReverb = NULL;
    }

    // destroy engine object, and invalidate all associated interfaces
    if (engineObject != NULL) {
        (*engineObject)->Destroy(engineObject);
        engineObject = NULL;
        engineEngine = NULL;
    }
}

//In SECONDS to go with Unity's convention
//This is not a true playback time since we never stop the track, the time will always be increasing.
//However we can internally utilize this as a reference point.
//TODO : Potentially this could be used as "buffer underrun detector"?  Checking current time vs expected time
float getPlaybackTimeAbsolute(int playerIndex) {
    SLPlayItf bqPlayerPlay = bqPlayerPlays[playerIndex];
    SLmillisecond playbackTime;
    (*bqPlayerPlay)->GetPosition(bqPlayerPlay, &playbackTime);
    return playbackTime / (float) 1000;
    Log("Playback time is %d", playbackTime);
}

//Converting seconds to "times" to call the double buffering callback.
//It can also "revive" an ended track also, since we are using the always playing approach.
//(The callback is always running, so when we change the callback state it will pick up the data)
void setPlaybackTime(int playerIndex, float offsetSeconds){

    if(offsetSeconds < 0) offsetSeconds = 0;
    CallbackState cbc = bqCallbackStates[playerIndex];
    //Change only timesPlayed such that it is equivalent to the offsetSeconds.
    //1 "times" = 1 nativeBufferSize (byte)
    int offsetSamples = (int)((nativeSamplingRate) * offsetSeconds);
    int offsetBytes = offsetSamples * (loadedAudioSpecs[cbc.sourceIndex-1].bitDepth/8) * loadedAudioSpecs[cbc.sourceIndex-1].channels; //16-bit = 2 bytes
    int timesRequired = offsetBytes / nativeBufferSize;
    int remainderBytes = offsetBytes % nativeBufferSize;
    Log("%d mod %d equals %d", offsetBytes, nativeBufferSize, remainderBytes);
    cbc.timesPlayed = timesRequired;
    cbc.offsetByte = remainderBytes;
    cbc.startPlaybackTimeAbsolute = getPlaybackTimeAbsolute(playerIndex) - offsetSeconds;
    //Instantly disable paused state with this.
    cbc.savedPlaybackTimeAbsolute = -1;

    Log("Set Playback Time to %f seconds : offS %d offB %d times %d remainder %d remembered start time %f",
        offsetSeconds, offsetSamples, offsetBytes, timesRequired, remainderBytes, cbc.startPlaybackTimeAbsolute);
    //Total times required unchanged.
    bqCallbackStates[playerIndex] = cbc;
}

// Native Audio will never ever stop the AudioSource, so this callback will keep running forever.
// To stop/play we have to modify the CallbackState and the callback should take an appropriate action automatically.
void doubleBufferingCallback(SLAndroidSimpleBufferQueueItf bq, void *context) {

    //The `context` is an **address** to the callback data.

    CallbackState *cs = (CallbackState *)context;

    //Log("Callback : Current context data  - %d %d %d %d ", cs->timesPlayed, cs->totalTimesRequired, cs->playerIndex, cs->sourceIndex);

    SLresult result;

    //This includes the starting state where this is -1 == -1
    // >= is for when we ser playback time and it goes over totalTimesRequired, it would results in a silence.
    if(cs->timesPlayed >= cs->totalTimesRequired)
    {
        if(cs->trackLoop == 1)
        {
            //Not returning to silence, returns to the beginning.
            //Should set times played to 0 along with correct data for pause/resume/etc.
            setPlaybackTime(cs->playerIndex, 0);
            //Not return!
        }
        else
        {
            //if not and we let 2 buffer became both vacant, the track will be stopped and AndroidAudioPolicy will trigger.. (bad)
            //Log("Callback : Playing silence");
            cs->playingSilence = 1;
            result = (*bq)->Enqueue(
                    bq,
                    silence,
                    (SLuint32)nativeBufferSize
            );
            assert(result == SL_RESULT_SUCCESS);
            return;
        }
    }

    cs->playingSilence = 0;
    result = (*bq)->Enqueue(
            bq,
            ((char*)loadedAudioCollection[cs->sourceIndex - 1]) + (cs->timesPlayed * nativeBufferSize) + cs->offsetByte, //the offset is by char (byte) not short
            nativeBufferSize - (SLuint32)cs->offsetByte
    );

    //The offset for pause/play function only works once.
    cs->offsetByte = 0;
    cs->timesPlayed ++;

    SLAndroidSimpleBufferQueueState st;
    (*bq)->GetState(bq, &st);

    Log("Callback : Now will play %d/%d (Buffer Count %d, Buffer Index %d) Enq result %d",cs->timesPlayed, cs->totalTimesRequired, st.count, st.index, result);

    assert(result == SL_RESULT_SUCCESS);
}

void setVolume(int playerIndex, float volume) {
    Log("Volume : %d %f", playerIndex, volume);
    SLVolumeItf bqPlayerVolume = bqPlayerVolumes[playerIndex];
    (*bqPlayerVolume)->SetVolumeLevel(bqPlayerVolume,
                                      (SLmillibel) (20 * log10(volume) * 100)); //1dB = 100 millibel
}

void setPan(int playerIndex, float pan) {
    Log("Panning : %d %f", playerIndex, pan );
    SLVolumeItf bqPlayerVolume = bqPlayerVolumes[playerIndex];
    (*bqPlayerVolume)->SetStereoPosition(bqPlayerVolume, (SLpermille) (pan * 1000));
}

//This stop audio is late by 2*bufferSize since we rely on the callback to stop according to the state.
void stopAudio(int playerIndex) {
    CallbackState cbc = bqCallbackStates[playerIndex];
    cbc.timesPlayed = cbc.totalTimesRequired; //So it stops in the callback without actually stopping the source..
    cbc.trackLoop = 0;
    bqCallbackStates[playerIndex] = cbc;
}

//In SECONDS to go with Unity's convention
float getPlaybackTime(int playerIndex) {
    //We no longer can ask playback time from SLPlayItf, since we are using "always playing silence" way of stopping.
    CallbackState cbc = bqCallbackStates[playerIndex];
    //-1 of savedTimesPlayed is the pausing state.
    if(cbc.savedTimesPlayed == -1)
    {
        //Not pausing, there are 2 cases : ended or not
        if(cbc.timesPlayed >= cbc.totalTimesRequired)
        {
            //When it runs over to the silence, we answer with unpadded audio length.
            //It is then possible to get a playback time a bit higher than this value right before it ends.
            return loadedAudioSpecs[cbc.sourceIndex - 1].lengthSeconds;
        }
        else
        {
            //We ask the time now vs the remembered time at start.
            return  getPlaybackTimeAbsolute(playerIndex) - cbc.startPlaybackTimeAbsolute;
        }
    }
    else
    {
        //Pausing, we saved the time at the moment of pausing.
        return cbc.savedPlaybackTimeAbsolute - cbc.startPlaybackTimeAbsolute;
    }
}

//Call from C# to give Unity-loaded bytes omgomg
//What's in Unity has to be converted to 16-bit per sample not float
int sendByteArray(signed char* byteArrayInput, int byteSize, int channels, int samplingRate, int resamplingQuality)
{
    size_t sizeOfDataChunk = (size_t)byteSize;
    assert(channels == 1 || channels == 2);

    //If the channel is 1, we duplicate it so that it becomes interleaved stereo.
    signed char* sterilized;
    if(channels == 1)
    {
        sterilized = calloc(sizeOfDataChunk * 2, sizeof(signed char*));

        //Since we locked to 16 bit, we iterate in a unit of 2 bytes
        for(int i = 0; i < sizeOfDataChunk / 2 ; i++)
        {
            //L
            sterilized[i*4] = byteArrayInput[(i*2)];
            sterilized[(i*4)+1] = byteArrayInput[(i*2)+1];
            //R
            sterilized[(i*4)+2] = byteArrayInput[(i*2)];
            sterilized[(i*4)+3] = byteArrayInput[(i*2)+1];
        }
        //There is no release of byteArrayInput in this method, it is safe to replace it.
        byteArrayInput = sterilized;
        sizeOfDataChunk *= 2;
    }

    //If resampling is needed, this would change later but we will need to free the input ones in any case.
    //byteArrayInput is directly at the data, not including the header.
    short *shortArrayUse = (short*) byteArrayInput;

    //Use the size we found in the "data" header of WAV file. It is the true size of our PCM data.
    size_t shortLength = sizeOfDataChunk / 2;
    size_t unpaddedShortLength;

    //Resampling audio to match native rate!
    if (samplingRate != nativeSamplingRate) {

        float ratio = nativeSamplingRate / ((float) samplingRate);

        //Output might be bigger or smaller. But since we use 44100 audio and there are many 48000 devices out there
        //It is likely bigger...

        //Also make sure that it is even number so that it is in full stereo on each byte
        size_t resampledArrayShortLength = (size_t)floor(shortLength * ratio);
        resampledArrayShortLength += resampledArrayShortLength % 2;

        // We have remembered the native buffer size of the device
        // "You should construct your audio buffers so that they contain an exact multiple of this number.
        // If you use the correct number of audio frames, your callbacks occur at regular intervals, which reduces jitter."

        // Here we will make the resampled array larger than necessary, to make multiple of that number.
        // The buffer's unit is in frame, we have 2 channels.
        // Remaining to add to A to make a multiple of B is B - (A % B)

        size_t addLength =
                (nativeBufferSize - ((resampledArrayShortLength / 2) % nativeBufferSize)) * 2;
        Log("Make a multiple of native buffer rate %d , adding %d to RESAMPLED length %d",
            nativeBufferSize, addLength, resampledArrayShortLength);
        unpaddedShortLength = resampledArrayShortLength;
        resampledArrayShortLength += addLength;

        //Ensure that the sound is bigger than native buffer size * 2.. (who would play sound that small anyways??)
        //Because the Play function will enqueue nativeBufferSize * 2 without error checking. (*2 not seen because that is short length)
        resampledArrayShortLength = resampledArrayShortLength < nativeBufferSize ? nativeBufferSize
                                                                                 : resampledArrayShortLength;

        float *floatArrayForSRCIn = calloc(shortLength, sizeof(float *));
        float *floatArrayForSRCOut = calloc(resampledArrayShortLength, sizeof(float *));

        //SRC takes float data.
        src_short_to_float_array((short*)byteArrayInput, floatArrayForSRCIn, (int)shortLength);

        SRC_DATA dataForSRC;
        dataForSRC.data_in = floatArrayForSRCIn;
        dataForSRC.data_out = floatArrayForSRCOut;

        //This is always stereo, since we have already "hacked" the mono to stereo lol
        dataForSRC.input_frames = shortLength / 2;
        dataForSRC.output_frames = resampledArrayShortLength / 2;
        dataForSRC.src_ratio = ratio; //This is in/out and it is less than 1.0 in the case of upsampling.

        Log("First element before resampling %d", beginningOfPCMData[0]);

        //I hope SRC fill in the padded data that we made multiple of just fine?

        Log("Resampling using SRC : Ratio %f Input short length %d Resampled length %d Player rate %d ",
            ratio, shortLength, resampledArrayShortLength, nativeSamplingRate);

        //Use the SRC library.
        /*int error =*/ src_simple(&dataForSRC, resamplingQuality, 2);

        Log("Resampling result : Input used %ld Output gen %ld Return code %s",
            dataForSRC.input_frames_used, dataForSRC.output_frames_gen,
            src_strerror(error));
        //Now get the data out. We need a yet another short array for this.
        //The old data in shortArrayUse being overwritten is still in the input argument. We can still release it.
        shortArrayUse = calloc(resampledArrayShortLength, sizeof(short *));
        src_float_to_short_array(floatArrayForSRCOut, shortArrayUse, (int)resampledArrayShortLength);
        shortLength = resampledArrayShortLength;

        free(floatArrayForSRCIn);
        free(floatArrayForSRCOut);
    } else {

        //Ensuring even number not needed, since if the input data is stereo that would be the case.
        //shortLength += shortLength % 2;

        // We have remembered the native buffer size of the device
        // "You should construct your audio buffers so that they contain an exact multiple of this number.
        // If you use the correct number of audio frames, your callbacks occur at regular intervals, which reduces jitter."

        // Here we will make the resampled array larger than necessary, to make multiple of that number.
        // The buffer's unit is in frame, we have 2 channels.
        // Remaining to add to A to make a multiple of B is B - (A % B)

        // When playing for real we will use 2 buffers. We will queue an audio equal to exactly device's native rate.
        // But it might make the audio glitch when the game lags, as it could not enqueue such small buffer in time?
        // anyways we put low latency first and foremost. We made a multiple of that size here, it means the last one will be
        // exactly at the end.

        size_t addLength = (nativeBufferSize - ((shortLength / 2) % nativeBufferSize)) * 2;
        Log("Make a multiple of native buffer rate, adding %d to length %d",
            addLength, shortLength);

        unpaddedShortLength = shortLength;
        shortLength += addLength;

        //Ensure that the sound is bigger than native buffer size * 2.. (who would play sound that small anyways??)
        //Because the Play function will enqueue nativeBufferSize * 2 without error checking. (*2 not seen because that is short length)
        shortLength = shortLength < nativeBufferSize ? nativeBufferSize : shortLength;
    }

    Log("Short length that will be used %d, unpadded length %d", shortLength, unpaddedShortLength);
    Log("First element %d", shortArrayUse[0]);

    //Next we try to do List style for storing pointer to audio memory.
    amountOfLoadedAudio++;
    loadedAudioCollection = realloc(loadedAudioCollection, amountOfLoadedAudio * sizeof(jshort *));
    loadedAudioSpecs = realloc(loadedAudioSpecs, amountOfLoadedAudio * sizeof(AudioSpecs));

    int newIndex = amountOfLoadedAudio - 1;

    //Alloc the same amount of memory and copy all audio data

    if (samplingRate != nativeSamplingRate) {
        //In case of resampling we have already allocated the array as a part of that routine.
        //So directly give that one to the collection.
        loadedAudioCollection[newIndex] = shortArrayUse;
    } else {
        //In this case our data is still in the java/C# land. We have to copy them.
        loadedAudioCollection[newIndex] = calloc(shortLength,
                                                 sizeof(short)); //zero out the area sice we want the padded to not sound.

        //shortArrayUse will be shorter than shortLength actually, since we padded it to be multiple of native rate.
        //So we use the old short of WAV data chunk.
        for (int i = 0; i < sizeOfDataChunk / 2; i++) {
            loadedAudioCollection[newIndex][i] = shortArrayUse[i]; //copy
        }
    }

    //The new memory area we made to stereorize the audio is now either resampled to new audio or
    //copied by the routine above. It is safe to release.
    if(channels == 1) {
        free(sterilized);
    }

    AudioSpecs fixedSpecs;
    //Store byte length, not short. Buffer queue wants to use byte length.
    //Use the new length that excluded the WAV header.
    fixedSpecs.byteLength = (SLuint32) (shortLength * 2);
    fixedSpecs.unpaddedByteLength = (SLuint32) (unpaddedShortLength * 2);

    //In the future we can support changing this.
    //Sampling rate is fixed to the fast track. We will resample everything to that.
    fixedSpecs.bitDepth = 16;
    fixedSpecs.channels = 2; //Since we force mono to stereo this is always correct.
    fixedSpecs.lengthSeconds = (fixedSpecs.unpaddedByteLength /
            (float)(fixedSpecs.bitDepth / 8) /
            (float)fixedSpecs.channels /
            (float)(nativeSamplingRate));
    loadedAudioSpecs[amountOfLoadedAudio -1] = fixedSpecs;

    Log("Specs : len %d unpaddedLen %d bit %d channels %d lenSec %f",
        fixedSpecs.byteLength, fixedSpecs.unpaddedByteLength, fixedSpecs.bitDepth, fixedSpecs.channels, fixedSpecs.lengthSeconds);

    return amountOfLoadedAudio; //It starts at ID = 1 which loads on the index 0!
}

//bytes of wav file received from Java side.
int Java_com_Exceed7_NativeAudio_NativeAudio_sendWavByteArray(JNIEnv *env, jclass clazz, jbyteArray array,
                                                          jint resamplingQuality) {
    //Copy the audio array to C part so that the remaining operations does not have to go to Java anymore.

    //SRC works with short pointer, so we are using that.
    jbyte *byteArrayInput = (*env)->GetByteArrayElements(env, array,
                                                         NULL); //True = make a copy but somehow it crashes...

    //The input is j"byte"Array, so what we got here is the correct size value for buffer player.
    jsize byteLength = (*env)->GetArrayLength(env, array);

    size_t sizeOfDataChunk = 0;
    short *beginningOfPCMData = NULL;
    int detectedSamplingRate = 0;
    int detectedChannels = 0;

    //Attempt to extract only data part out of a wav file
    //See the WAVE format layout : http://soundfile.sapp.org/doc/WaveFormat/
    for (int i = 0; i < byteLength - 3; ++i) {
        //byte is already a char size
        if (byteArrayInput[i] == 'd' &&
            byteArrayInput[i + 1] == 'a' &&
            byteArrayInput[i + 2] == 't' &&
            byteArrayInput[i + 3] == 'a') {
            //Deref the int value next to the letter "a" to get the size.
            sizeOfDataChunk = (size_t) *((int *) (byteArrayInput + i + 4));

            //The addition is in byte pointer, after that cast to short pointer.
            beginningOfPCMData = (short *) (byteArrayInput + i + 4 + 4);
        }
    }

    detectedChannels = *((short *) (byteArrayInput + 22));

    //Very intelligence sampling rate detection algorithm
    detectedSamplingRate = *((int *) (byteArrayInput + 24));

    Log("Trying to remove WAV header. size of data %d, offset %ld, sampling rate %d",
        sizeOfDataChunk, (char *) beginningOfPCMData - (char *) byteArrayInput,
        detectedSamplingRate);
    assert(beginningOfPCMData != NULL);
    assert(sizeOfDataChunk != 0);
    assert(detectedSamplingRate != 0);

    // byteLength = include headers
    // sizeOfDataChunk = just the data part
    int loadedIndex = sendByteArray(byteArrayInput, (int)sizeOfDataChunk, detectedChannels, detectedSamplingRate, resamplingQuality);

    (*env)->ReleaseByteArrayElements(env, array, byteArrayInput,
                                     JNI_ABORT); //Abort = Do not sync back the array
    return loadedIndex;
}

void unloadAudio(int sourceIndex) {
    free(loadedAudioCollection[sourceIndex - 1]);
    //leave the length alone?
}

//Length in seconds like Unity.
float lengthBySource(int sourceIndex)
{
    return loadedAudioSpecs[sourceIndex - 1].lengthSeconds;
}

//One engine per project.
void createEngine() {
    SLresult result;

    // create engine
    result = slCreateEngine(&engineObject, 0, NULL, 0, NULL, NULL);
    assert(SL_RESULT_SUCCESS == result);
    (void) result;

    // realize the engine
    result = (*engineObject)->Realize(engineObject, SL_BOOLEAN_FALSE);
    assert(SL_RESULT_SUCCESS == result);
    (void) result;

    // get the engine interface, which is needed in order to create other objects
    result = (*engineObject)->GetInterface(engineObject, SL_IID_ENGINE, &engineEngine);
    assert(SL_RESULT_SUCCESS == result);
    (void) result;

    // output mix
    result = (*engineEngine)->CreateOutputMix(engineEngine, &outputMixObject, 0, NULL, NULL);
    assert(SL_RESULT_SUCCESS == result);
    (void) result;

    // realize the output mix
    result = (*outputMixObject)->Realize(outputMixObject, SL_BOOLEAN_FALSE);
    assert(SL_RESULT_SUCCESS == result);
    (void) result;
}

void Java_com_Exceed7_NativeAudio_NativeAudio_initialize(JNIEnv *env, jclass clazz, int sampleRate,
                                                         int bufSize, int numberOfAudioPlayer) {
    Log("Initializing with rate %d buffer size %d amount of tracks %d", sampleRate, bufSize, numberOfAudioPlayer);
    disposeIfAllocated(); //This allows you to reinitialize.
    createEngine();
    SLresult result;

    nativeSamplingRate = sampleRate * 1u;
    nativeBufferSize = (size_t)bufSize;
    silence = calloc(nativeBufferSize, sizeof(char) );

    // configure audio source
    SLDataLocator_AndroidSimpleBufferQueue loc_bufq = {SL_DATALOCATOR_ANDROIDSIMPLEBUFFERQUEUE, 2};

    //SL_SAMPLINGRATE_44_1 is actually SLuint32, I think we can just multiply and put number in instead of the enum
    SLDataFormat_PCM format_pcm = {SL_DATAFORMAT_PCM, 2, nativeSamplingRate * 1000u,
                                   SL_PCMSAMPLEFORMAT_FIXED_16, SL_PCMSAMPLEFORMAT_FIXED_16,
                                   SL_SPEAKER_FRONT_LEFT | SL_SPEAKER_FRONT_RIGHT,
                                   SL_BYTEORDER_LITTLEENDIAN};

    //Very important! This can enable fast audio path!!
    if (nativeSamplingRate) {
        format_pcm.samplesPerSec = nativeSamplingRate * 1000u;
    }

    SLDataSource audioSrc = {&loc_bufq, &format_pcm};

    // configure audio sink
    SLDataLocator_OutputMix loc_outmix = {SL_DATALOCATOR_OUTPUTMIX, outputMixObject};
    SLDataSink audioSnk = {&loc_outmix, NULL};

    const SLInterfaceID ids[] = {SL_IID_ANDROIDSIMPLEBUFFERQUEUE, SL_IID_VOLUME, SL_IID_PLAY }; //, SL_IID_ANDROIDCONFIGURATION};
    const SLboolean req[] = {SL_BOOLEAN_TRUE, SL_BOOLEAN_TRUE, SL_BOOLEAN_TRUE }; // , SL_BOOLEAN_TRUE};
    const int interfaceCount = 3;

    //Remember the successful creation count.
    audioPlayerCount = 0;

    //Next we will create many Audio Player to round robin all using that source and sink.

    for (int i = 0; i < numberOfAudioPlayer; ++i) {

        //New LOCAL variable allocated to receive the initialization;
        SLObjectItf bqPlayerObject;
        SLPlayItf bqPlayerPlay;
        SLAndroidSimpleBufferQueueItf bqPlayerBufferQueue;
        SLVolumeItf bqPlayerVolume;
        //SLAndroidConfigurationItf bqPlayerConfig;
        CallbackState bqCallbackState;

        bqCallbackState.sourceIndex = -555;
        bqCallbackState.playerIndex = -555;
        bqCallbackState.totalTimesRequired = -555;
        bqCallbackState.timesPlayed = -555;
        bqCallbackState.trackLoop = 0;

        // Below this point, it is an interaction between IEngine and AudioPlayer and finally to AudioTrack.
        // View the source by cloning these :
        // git clone https://android.googlesource.com/platform/frameworks/av
        // git clone https://android.googlesource.com/platform/frameworks/wilhelm

        // The pointer invoke ask to IEngine to instantiate AudioPlayer, which maps to Android's AudioTrack

        Log("Creating audio player %d..", i);

        result = (*engineEngine)->CreateAudioPlayer(engineEngine, &bqPlayerObject, &audioSrc,
                                                    &audioSnk,
                                                    interfaceCount, ids, req);
        if (result == SL_RESULT_MEMORY_FAILURE) {
            //On Android P and Le X620 somehow it fails here and not below when out of audio tracks..?
            Log("At limit for a different reason... We get a total of %d players.",
                audioPlayerCount);
            break;
        }
        assert(SL_RESULT_SUCCESS == result);
        (void) result;

        /* Keep for memories/reference. A code to "config before realizing".
        Log("Configuration before realizing %d..", i);

        //We will config something... it is the only thing available before realization
        result = (*bqPlayerObject)->GetInterface(bqPlayerObject, SL_IID_ANDROIDCONFIGURATION, &bqPlayerConfig);
        assert(SL_RESULT_SUCCESS == result);
        (void) result;

        Log("Configuration before realizing (2) %d..", i);

        // This stream type match with what Unity use (-1 = default).
        // If not specifying this, it will not be default to "default" but to 3 (music)
        SLint32 streamType = -1;
        result = (*bqPlayerConfig)->SetConfiguration(bqPlayerConfig, SL_ANDROID_KEY_STREAM_TYPE, &streamType, sizeof(SLint32));
        assert(SL_RESULT_SUCCESS == result);
        (void) result;
         */

        Log("Realizing audio player %d..", i);

        // This realize step is where AudioFlinger will complain if there is no more available...
        result = (*bqPlayerObject)->Realize(bqPlayerObject, SL_BOOLEAN_FALSE);
        if (result == SL_RESULT_CONTENT_UNSUPPORTED || result == SL_RESULT_MEMORY_FAILURE) {

            //This means the AudioFlinger is at limit!!
            //Interestingly the MEMORY_FAILURE case only happen with Android Pie onwards.
            //Other previous versions returns CONTENT_UNSUPPORTED

            Log("At limit! We get a total of %d players.", audioPlayerCount);
            break;
        }

        assert(SL_RESULT_SUCCESS == result);
        (void) result;


        result = (*bqPlayerObject)->GetInterface(bqPlayerObject, SL_IID_PLAY, &bqPlayerPlay);
        assert(SL_RESULT_SUCCESS == result);
        Log("Play %d", result);
        (void) result;

        result = (*bqPlayerObject)->GetInterface(bqPlayerObject, SL_IID_ANDROIDSIMPLEBUFFERQUEUE,
                                                 &bqPlayerBufferQueue);
        assert(SL_RESULT_SUCCESS == result);
        Log("BufferQueue %d", result);
        (void) result;


        result = (*bqPlayerObject)->GetInterface(bqPlayerObject, SL_IID_VOLUME, &bqPlayerVolume);
        Log("Volume %d", result);
        assert(SL_RESULT_SUCCESS == result);
        (void) result;

        //All is well so we make room for those!

        int allocAmount = i + 1;
        bqPlayerObjects = realloc(bqPlayerObjects, allocAmount * sizeof(SLObjectItf));
        bqPlayerPlays = realloc(bqPlayerPlays, allocAmount * sizeof(SLPlayItf));
        bqPlayerBufferQueues = realloc(bqPlayerBufferQueues,
                                       allocAmount * sizeof(SLAndroidSimpleBufferQueueItf));
        bqPlayerVolumes = realloc(bqPlayerVolumes, allocAmount * sizeof(SLVolumeItf));
        bqCallbackStates = realloc(bqCallbackStates,
                                               allocAmount * sizeof(CallbackState));

        bqPlayerObjects[i] = bqPlayerObject;
        bqPlayerPlays[i] = bqPlayerPlay;
        bqPlayerBufferQueues[i] = bqPlayerBufferQueue;
        bqPlayerVolumes[i] = bqPlayerVolume;
        bqCallbackStates[i] = bqCallbackState;

        (*bqPlayerVolume)->EnableStereoPosition(bqPlayerVolume, SL_BOOLEAN_TRUE);

        //Yay! Working instance!
        audioPlayerCount++;
        Log("Successfully created player %d", audioPlayerCount);
    }

    //From the total actually created audio player count
    for (int i = 0; i < audioPlayerCount; ++i) {
        SLAndroidSimpleBufferQueueItf bqPlayerBufferQueue = bqPlayerBufferQueues[i] ;
        SLPlayItf bqPlayerPlay = bqPlayerPlays[i];

        //Setup the starting state, that is always playing with callback running.

        //The only chance to setup the callback is now, when it is currently stopped. It will not be stopped ever again.
        //realloc can change memory area therefore we cannot do this in the previous loop.

        result = (*bqPlayerBufferQueue)->RegisterCallback(bqPlayerBufferQueue,
                                                          doubleBufferingCallback,
                                                          bqCallbackStates + i); //The callback context is an **address** to those data.
        assert(SL_RESULT_SUCCESS == result);
        (void) result;

        //Kickstart the callback chain with double buffered... silence
        for (int j = 0; j < 2; ++j) {
            result = (*bqPlayerBufferQueue)->Enqueue(bqPlayerBufferQueue,
                                                     silence,
                                                     (int)nativeBufferSize); //Small! It could be a multiple of this.. but we want the lowest latency.

            //SL_RESULT_BUFFER_INSUFFICIENT is possible if we are doing it wrong
            Log("Silence queueing result : %d", result);
        }

        //We are using the "always playing silence" policy. So the state should be playing even after fresh allocation.
        result = (*bqPlayerPlay)->SetPlayState(bqPlayerPlay, SL_PLAYSTATE_PLAYING);
        assert(SL_RESULT_SUCCESS == result);
        (void) result;

    }
    Log("We get a total of %d players.", audioPlayerCount);
}

static int currentRoundRobin = -1;

//A "virtual pause", make the track jump to silence while remembering the current bytes.
void trackPause(int playerIndex)
{
    CallbackState cbc = bqCallbackStates[playerIndex];
    if(cbc.savedTimesPlayed == -1 && cbc.playingSilence == 0)
    {
        cbc.savedTimesPlayed = cbc.timesPlayed;
        //This will appears to "pause" in our "always playing silence" model.
        cbc.timesPlayed = cbc.totalTimesRequired;

        //Make it so that on resume, it can resume as a looping audio.
        cbc.savedTrackLoopStatus = cbc.trackLoop;
        cbc.trackLoop = 0;
        //When we ask the playback time while pausing, it is this time - start time absolute.
        //We must preserve the startPlaybackTimeAbsolute so that getPlaybackTime while pausing is possible.
        //(The actual track time will run ahead because of silence playing)
        cbc.savedPlaybackTimeAbsolute = getPlaybackTimeAbsolute(playerIndex);
        bqCallbackStates[playerIndex] = cbc;
        Log("Track paused with this times played %d", cbc.savedTimesPlayed);
    }
}

//Make the track jump back to remembered times played.
void trackResume(int playerIndex)
{
    CallbackState cbc = bqCallbackStates[playerIndex];
    if(cbc.savedTimesPlayed != -1)
    {
        Log("Track resumed with this times played %d", cbc.savedTimesPlayed);
        cbc.timesPlayed = cbc.savedTimesPlayed;
        cbc.savedTimesPlayed = -1;
        //Restoring the start playback time absolute so that it is correct when we take a difference with it later.
        cbc.startPlaybackTimeAbsolute = getPlaybackTimeAbsolute(playerIndex) - getPlaybackTime(playerIndex) ;
        cbc.trackLoop = cbc.savedTrackLoopStatus;
        cbc.savedPlaybackTimeAbsolute = -1;
        bqCallbackStates[playerIndex] = cbc;
    }
}

int playAudio(int sourceIndex, PlayOptions playOptions) {

    //SLresult result;
    int chosenPlayerIndex;
    if (playOptions.audioPlayerIndex <= -1 || playOptions.audioPlayerIndex >=
                             audioPlayerCount) //e.g. if we managed to get 2 players, only index 0 and 1 are invalid.
    {
        currentRoundRobin = (currentRoundRobin + 1) % audioPlayerCount;
        chosenPlayerIndex = currentRoundRobin;
    } else {
        Log("Specifying an index manually via PlayOptions : %d", playOptions.audioPlayerIndex);
        chosenPlayerIndex = playOptions.audioPlayerIndex;
    }

    //SLPlayItf bqPlayerPlay = bqPlayerPlays[chosenPlayerIndex];
    //SLAndroidSimpleBufferQueueItf bqPlayerBufferQueue = bqPlayerBufferQueues[chosenPlayerIndex];

    Log("Playing Source Index %d Chosen player %d ", sourceIndex,
        chosenPlayerIndex);


    // I have not put any checks about whether the audio is TOO SMALL in here to minimize latency..
    // and when loading I have ensured that if the audio manages to be smaller than native rate * 2 it is padded so that it is big enough
    // for this no-check play.

    // This is the one-big-buffer way.
    // Kept for memories but it sucks latency wise + does not work with "always playing" design.
    /*
    result = (*bqPlayerBufferQueue)->Enqueue(bqPlayerBufferQueue,
                                             loadedAudioCollection[sourceIndex - 1],
                                             loadedAudioLengths[sourceIndex - 1]);
    //SL_RESULT_BUFFER_INSUFFICIENT is possible if we are doing it wrong
    Log("Buffer queueing result : %d", result);
    */


    // This is the double buffering way. It enqueue only small audio and continues loading more via a callback.
    // The same Enqueue command called 2 consecutive times would go to different buffer. We start with both filled up.
    // Should results in a lower latency, but I heard some devices cannot keep up with the callback..

    //The enqueue is in-place, maybe we don't need to worry? From the docs :
    //"The buffers that are queued in a player object are used in place and are not required to
    //be copied by the device, although this may be implementation-dependent"

    //The "size" is in byte, we read audio from Java side as a byte array so its length is already correct.
    //It does not matter what kind of input pointer, it runs based on the size and initial settings when we create the BQ.

    //With the always playing policy this is now tricky. Because callbacks are in progress. (2 of them - double buffering)
    //We cannot enqueue while both two are full. We must wait until they became vacant.
    //But to change the course of callback it must be via the context object only!

    //So how about we left enqueuing to the callback entirely?

    /* Kept for memory, this is enqueue on play. Now we leave that task to the callback.
    for (int i = 0; i < 2; ++i) {
        result = (*bqPlayerBufferQueue)->Enqueue(bqPlayerBufferQueue,
                                                 ((char *) (loadedAudioCollection[sourceIndex - 1])) + (i * nativeBufferSize), //This should enqueue the first 2 bytes
                                                 nativeBufferSize); //Small! It could be a multiple of this.. but we want the lowest latency.

        //SL_RESULT_BUFFER_INSUFFICIENT is possible if we are doing it wrong
        Log("Buffer queueing result : %d", result);
    }
    */

    //The always playing source will notice the change of state and will not continue playing the old lingering sound.

    CallbackState cbc = bqCallbackStates[chosenPlayerIndex];
    cbc.sourceIndex = sourceIndex;
    //cbc.timesPlayed = 2; //Use this when enqueue on play. Because we have to start at the 3rd byte.
    cbc.timesPlayed = 0; //The currently playing silent that just ended will see this and push a real audio at pointer + 0 in it.
    cbc.savedTimesPlayed = -1; //A special number that TrackResume will do nothing.

    //It must be perfectly divisible..
    cbc.totalTimesRequired = (loadedAudioSpecs[sourceIndex -1].byteLength) / nativeBufferSize;
    cbc.playerIndex = chosenPlayerIndex;

    cbc.trackLoop = playOptions.trackLoop;

    bqCallbackStates[chosenPlayerIndex] = cbc;

    //Will saving the absolute time even if offset is 0
    setPlaybackTime(chosenPlayerIndex, playOptions.offsetSeconds);

    setVolume(chosenPlayerIndex, playOptions.volume);
    setPan(chosenPlayerIndex, playOptions.pan);

    return chosenPlayerIndex;
}

void Java_com_Exceed7_NativeAudio_NativeAudio_disposeIfAllocated(JNIEnv *env, jclass clazz) {
    disposeIfAllocated();
}
