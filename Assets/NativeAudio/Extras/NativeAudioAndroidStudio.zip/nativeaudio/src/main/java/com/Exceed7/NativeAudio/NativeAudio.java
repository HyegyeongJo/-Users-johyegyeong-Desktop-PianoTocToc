// Native Audio
// Copyright (c) 2018, Sirawat Pitaksarit, Exceed7 Experiments <5argon@exceed7.com>
// Problems/suggestions : 5argon@exceed7.com

package com.Exceed7.NativeAudio;

import android.app.Activity;
import android.app.Application;
import android.content.Context;
import android.content.res.AssetFileDescriptor;
import android.content.res.AssetManager;
import android.media.AudioDeviceInfo;
import android.media.AudioManager;

import java.io.IOException;
import java.io.InputStream;
import java.lang.annotation.Native;

import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;

import com.unity3d.player.UnityPlayer;

public class NativeAudio {

    //Log is visible on adb logcat
    private final static boolean enableLogging = false;

    private static void Log(String message) {
        if (enableLogging) {
            Log.i("Android Native Audio", message);
        }
    }

    private static boolean initializedOnce = false;

    //This is to be interop with C# side via JNI digging.
    public class DeviceAudioInformation
    {
        int nativeSamplingRate;
        int optimalBufferSize;
        boolean lowLatencyFeature;
        boolean proAudioFeature;
        AudioDeviceInfo[] outputDevices;
    }

    private static Application.ActivityLifecycleCallbacks lifecycleTracker = new Application.ActivityLifecycleCallbacks() {
        //On pause -> resume it goes in this order :
        //Pause SaveState Stopped -(after coming back)-> Start Resume
        @Override
        public void onActivityCreated(Activity var1, Bundle var2) {
            //Log.i("Lifecycle", "CRE");
        }

        @Override
        public void onActivityStarted(Activity var1) {
            //Log.i("Lifecycle", "STARTED");
        }

        @Override
        public void onActivityResumed(Activity var1) {
            NativeAudio.Initialize(
                    rememberedInitialization.numberOfAudioPlayer,
                    rememberedInitialization.minimumBufferSize,
                    false
            );
            //Log.i("Lifecycle", "RESUMED");
        }

        @Override
        public void onActivityPaused(Activity var1){
            //Log.i("Lifecycle", "PAUSED");
        }

        @Override
        public void onActivityStopped(Activity var1){
            disposeIfAllocated();
            //Log.i("Lifecycle", "STOPPED");
        }

        @Override
        public void onActivitySaveInstanceState(Activity var1, Bundle var2){
            //Log.i("Lifecycle", "SAVE STATE");
        }

        @Override
        public void onActivityDestroyed(Activity var1){
            //Log.i("Lifecycle", "DESTROYED");
        }
    };

    private static DeviceAudioInformation GetDeviceAudioInformation()
    {
        DeviceAudioInformation audioInfo = new NativeAudio().new DeviceAudioInformation();
        // Match the created audio player with device native sampling rate and native buffer size so that we get a FAST TRACK if possible.
        // If the native rate is 48000Hz, there is an upsampling performed for all loaded audio since we agreed on a rule of using only 44100Hz audio.

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) {
            AudioManager myAudioMgr = (AudioManager) UnityPlayer.currentActivity.getSystemService(android.content.Context.AUDIO_SERVICE);
            PackageManager packageManager = UnityPlayer.currentActivity.getPackageManager();

            audioInfo.nativeSamplingRate = Integer.parseInt(myAudioMgr.getProperty(AudioManager.PROPERTY_OUTPUT_SAMPLE_RATE));
            Log("NATIVE SAMPLING RATE : " + audioInfo.nativeSamplingRate);

            /*
            The PROPERTY_OUTPUT_FRAMES_PER_BUFFER property indicates the number of audio frames that the HAL (Hardware Abstraction Layer) buffer can hold. You should construct your audio buffers so that they contain an exact multiple of this number. If you use the correct number of audio frames, your callbacks occur at regular intervals, which reduces jitter.
             */
            audioInfo.optimalBufferSize = Integer.parseInt(myAudioMgr.getProperty(AudioManager.PROPERTY_OUTPUT_FRAMES_PER_BUFFER));
            Log("OPTIMAL BUFFER SIZE : " + audioInfo.optimalBufferSize);


            if (Build.VERSION.SDK_INT >= 23) {
                //These are not used at all, but maybe useful when logging to know if the phone is up to the task or not.
                audioInfo.lowLatencyFeature = packageManager.hasSystemFeature(PackageManager.FEATURE_AUDIO_LOW_LATENCY);
                audioInfo.proAudioFeature = packageManager.hasSystemFeature(PackageManager.FEATURE_AUDIO_PRO);
                Log("LOW LATENCY FEATURE (indicates a continuous output latency of 45 ms or less) : " + String.valueOf(audioInfo.lowLatencyFeature));
                Log("PRO AUDIO FEATURE (indicates a continuous round-trip latency of 20 ms or less) : " + String.valueOf(audioInfo.proAudioFeature));

                audioInfo.outputDevices = myAudioMgr.getDevices(AudioManager.GET_DEVICES_OUTPUTS);
            }
        }
        return audioInfo;
    }

    private static class RememberedInitialization
    {
        int numberOfAudioPlayer;
        int minimumBufferSize;
    }
    private static RememberedInitialization rememberedInitialization;

    public static int Initialize(int numberOfAudioPlayer, int minimumBufferSize, boolean preserveOnMinimize) {

        if(!preserveOnMinimize)
        {
            //This will properly dispose all sources on minimize, then allocate back with the same setup on restore.
            rememberedInitialization = new RememberedInitialization();
            rememberedInitialization.numberOfAudioPlayer = numberOfAudioPlayer;
            rememberedInitialization.minimumBufferSize = minimumBufferSize;
            UnityPlayer.currentActivity.getApplication().registerActivityLifecycleCallbacks(lifecycleTracker);
        }

        DeviceAudioInformation dai = GetDeviceAudioInformation();

        //Start at optimal buffer size minimum.
        int bufferSizeToInitialize = dai.optimalBufferSize;

        // If provided custom minimum value, we choose the next number over that value
        // that is also a multiple of optimal buffer size.
        // [See the reason of increasing by multiple](https://developer.android.com/ndk/guides/audio/audio-latency#buffer-size).
        if(minimumBufferSize != -1 && bufferSizeToInitialize < minimumBufferSize)
        {
            int multipleOfOptimalFloored = minimumBufferSize / dai.optimalBufferSize;
            bufferSizeToInitialize = dai.optimalBufferSize * (multipleOfOptimalFloored + 1);
            Log("Adjusted buffer size to : " + bufferSizeToInitialize + " according to minimum " + minimumBufferSize);
        }

        // Why can't I allow you to go lower as a way to "overclock" the audio with even faster latency?
        // I have tested ridiculous buffer size like "1", it is able to intialize sources of that size
        // but playing any audio on it freeze the phone. Not even a crash.
        // Soft button to go back to home stopped working. `adb logcat` also freezes.
        // The only way to recover is to hard restart the phone. It seems HAL layer is trying
        // too hard to read the small buffer it busy the entire phone.

        // The business with Java is over!
        // Also we now can initialize multiple times.
        // Managed side should let it come to this point. (with potentially new buffer size)
        initialize(dai.nativeSamplingRate , bufferSizeToInitialize, numberOfAudioPlayer);

        initializedOnce = true;

        Log("Initialized");
        return 0; //No error...
    }

    public static int LoadAudio(String audioPath, int resamplingQuality) {

        if(audioPath.equals(""))
        {
            Log("Loading SILENCE");
        }
        else {
            Log("Loading " + audioPath);
        }

        if (!initializedOnce) {
            //LoadAudio cannot call Initialize automatically because we need to know the desired AudioTrack amount.
            //This number setting is on the managed side, so we leave the Load -> Initialize logic to that.
            //(That is, we should never arrive at this point if the code at managed side is correct.)
            Log.e("Android Native Audio", "Cannot load an audio without initializing Native Audio first.");
            return -1;
        }

        Context context = UnityPlayer.currentActivity;

        //Normally, Application.streamingAssetsPath looks like this :
        //jar:file:///data/app/com.Exceed7.NativeAudio-1/base.apk!/assets

        //In OBB, Application.streamingAssetsPath looks like this :
        //jar:file:///storage/emulated/0/Android/obb/com.Exceed7.NativeAudio/main.1.com.Exceed7.NativeAudio.obb!/assets

        //context.getAssets() cannot find things there. It will look in the base APK and found nothing...
        //This is where we will use : https://github.com/google/play-apk-expansion

        AssetManager assetManager = context.getAssets();

        ZipResourceFile obbFiles;

        int versionCode = -1;
        try {
            versionCode = context.getPackageManager().getPackageInfo(context.getPackageName(), 0).versionCode;
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
            return -1;
        }

        try {
            //Even without OBB present, this will "new" the ZipResourceFile anyways.
            //With OBB, it collects all of the expansion and patch them into one.
            obbFiles = APKExpansionSupport.getAPKExpansionZipFile(context, versionCode, 0);
        } catch (IOException e) {
            e.printStackTrace();
            return -1;
        }

        if (enableLogging) {
            try {
                ZipResourceFile.ZipEntryRO[] allEntries = obbFiles.getAllEntries();
                for (ZipResourceFile.ZipEntryRO zero : allEntries) {
                    Log("Expansion file content : " + zero.mFileName + " " + zero.mZipFileName);
                }
            }
            catch(NullPointerException ne)
            {
                //We don't have any OBB to log.
            }
        }

        byte[] music;
        if(audioPath.equals(""))
        {
            //You can load a stereoSilence with empty audio path.
            music = hexStringToByteArray(stereoSilence);
        }
        else {
            try {
                AssetFileDescriptor descriptor = assetManager.openFd(audioPath);
                music = new byte[(int) descriptor.getLength()];

                InputStream is = assetManager.open(audioPath);
                is.read(music);
                is.close();

                Log("Loaded audio " + audioPath + " from the main APK.");

            } catch (IOException e) {
                //Now is the chance to try looking at OBB...
                try {
                    AssetFileDescriptor descriptorFromObb = obbFiles.getAssetFileDescriptor("assets/" + audioPath);
                    music = new byte[(int) descriptorFromObb.getLength()];
                    InputStream is = obbFiles.getInputStream("assets/" + audioPath);
                    is.read(music);
                    is.close();

                    Log("Loaded audio " + audioPath + " from an OBB expansion file.");
                } catch (IOException | NullPointerException e2) {
                    //Null pointer is when we .getLength from an invalid descriptorFromObb.
                    Log("Error reading audio file " + audioPath);
                    e2.printStackTrace();
                    return -1;
                }
            }
        }

        // COPY the audio data to C side so that when we play
        // we don't have to go through Java again but directly from Unity to C code.
        // The upsampling will be here also if the native rate is 48000Hz

        int byteArrayIndexOfLoaded = sendWavByteArray(music, resamplingQuality);

        Log("Loaded to byteArrayIndex: " + byteArrayIndexOfLoaded);
        return byteArrayIndexOfLoaded;
    }

    //A specially-crafted delicious silence
    private static String stereoSilence = "52494646D400000057415645666D7420100000000100020044AC000010B102000400100064617461B000000001000100FDFFFDFF04000400FDFFFDFF0100010001000100FEFFFEFF02000200FFFFFFFF00000000000000000000000001000100FEFFFEFF03000300FCFFFCFF03000300FFFFFFFFFFFFFFFF02000200FEFFFEFF010001000000000000000000FFFFFFFF02000200FDFFFDFF03000300FFFFFFFFFFFFFFFF02000200FDFFFDFF0200020000000000FFFFFFFF01000100FFFFFFFF01000100FFFFFFFF02000200FDFFFDFF03000300FDFFFDFF04000400";

    public static byte[] hexStringToByteArray(String s) {
        int len = s.length();
        byte[] data = new byte[len / 2];
        for (int i = 0; i < len; i += 2) {
            data[i / 2] = (byte) ((Character.digit(s.charAt(i), 16) << 4)
                    + Character.digit(s.charAt(i+1), 16));
        }
        return data;
    }

    public static native int sendWavByteArray(byte[] byteArray, int resamplingQuality);
    public static native void initialize(int sampleRate, int bufSize, int numberOfAudioPlayer);
    public static native void disposeIfAllocated();

    static {
        System.loadLibrary("nativeaudioe7");
    }

}
